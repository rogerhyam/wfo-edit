<?php

require_once('../../../wfo_edit_secrets.php'); // outside the github root